<?php
// Simulated products
$products = array(
    array(
        'name' => 'Laptop',
        'category' => 'electronics',
        'price' => 800,
        'image' => 'laptop.jpg'
    ),
    array(
        'name' => 'T-Shirt',
        'category' => 'clothing',
        'price' => 20,
        'image' => 'tshirt.jpg'
    ),
    array(
        'name' => 'Book',
        'category' => 'books',
        'price' => 15,
        'image' => 'book.jpg'
    ),
);

$search = isset($_GET['search']) ? $_GET['search'] : '';
$category = isset($_GET['category']) ? $_GET['category'] : 'all';

foreach ($products as $product) {
    if (($category == 'all' || $product['category'] == $category) &&
        (empty($search) || stripos($product['name'], $search) !== false)) {
        echo "<div class='product'>";
        echo "<img src='images/" . $product['image'] . "'><br>";
        echo $product['name'] . "<br>";
        echo "$" . $product['price'] . "<br>";
        echo "</div>";
    }
}
?>
